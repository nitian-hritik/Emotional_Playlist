import { N, _ } from "../chunks/2.D1m5YoB_.js";
export {
  N as component,
  _ as universal
};
